package com.example.customerser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerSerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerSerApplication.class, args);
	}

}
